import os
os.system('pip install -e .')

